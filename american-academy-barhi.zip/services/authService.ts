
import { apiRequest } from './api';
import { AuthResponse, ApiResponse } from '../types';

export async function login(email: string, password: string): Promise<ApiResponse<AuthResponse>> {
  return apiRequest<AuthResponse>('/auth/login', 'POST', { email, password });
}

export async function register(name: string, email: string, password: string, phone?: string): Promise<ApiResponse<AuthResponse>> {
  return apiRequest<AuthResponse>('/auth/register', 'POST', { name, email, password, phone });
}

export async function logout(): Promise<ApiResponse<any>> {
  return apiRequest<any>('/auth/logout', 'POST');
}

export async function getProfile(): Promise<ApiResponse<any>> {
  return apiRequest<any>('/auth/profile', 'GET');
}

export async function updateProfile(data: FormData): Promise<ApiResponse<any>> {
  return apiRequest<any>('/auth/profile', 'POST', data); // Use POST for FormData, Laravel can handle _method PUT
}
