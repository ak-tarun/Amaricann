
import React, { useEffect, useState } from 'react';
import * as adminService from '../../services/adminService';
import { User, UserRole } from '../../types';
import LoadingSpinner from '../../components/LoadingSpinner';
import Card from '../../components/Card';
import Alert from '../../components/Alert';
import Button from '../../components/Button';
import Modal from '../../components/Modal';
import Input from '../../components/Input';

const AdminStudentsPage: React.FC = () => {
  const [students, setStudents] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<User | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
  });

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    setLoading(true);
    setError(null);
    const response = await adminService.getAllStudents();
    if (response.success && response.data) {
      setStudents(response.data);
    } else {
      setError(response.message || 'Failed to fetch students.');
    }
    setLoading(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const openAddModal = () => {
    setCurrentStudent(null);
    setFormData({ name: '', email: '', phone: '', password: '' });
    setIsModalOpen(true);
  };

  const openEditModal = (student: User) => {
    setCurrentStudent(student);
    setFormData({
      name: student.name,
      email: student.email,
      phone: student.phone || '',
      password: '', // Password should not be pre-filled
    });
    setIsModalOpen(true);
  };

  const handleModalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);
    setError(null);

    let response;
    const dataToSend = new FormData();
    dataToSend.append('name', formData.name);
    dataToSend.append('email', formData.email);
    dataToSend.append('phone', formData.phone);
    if (formData.password) {
      dataToSend.append('password', formData.password);
    }

    if (currentStudent) {
      // Update existing student
      response = await adminService.updateStudent(currentStudent.id, dataToSend);
    } else {
      // Create new student
      response = await adminService.createStudent(dataToSend);
    }

    if (response?.success) {
      setMessage(response.message || `Student ${currentStudent ? 'updated' : 'added'} successfully.`);
      setIsModalOpen(false);
      fetchStudents();
    } else {
      setError(response?.message || `Failed to ${currentStudent ? 'update' : 'add'} student.`);
    }
    setLoading(false);
  };

  const handleDelete = async (studentId: number) => {
    if (!window.confirm('Are you sure you want to delete this student?')) return;
    setLoading(true);
    setMessage(null);
    setError(null);
    const response = await adminService.deleteStudent(studentId);
    if (response.success) {
      setMessage(response.message || 'Student deleted successfully.');
      fetchStudents();
    } else {
      setError(response.message || 'Failed to delete student.');
    }
    setLoading(false);
  };

  const handleToggleStatus = async (student: User) => {
    setLoading(true);
    setMessage(null);
    setError(null);
    let response;
    if (student.status === 'active') {
      response = await adminService.suspendStudent(student.id);
    } else {
      response = await adminService.activateStudent(student.id);
    }

    if (response.success) {
      setMessage(response.message || `Student ${student.status === 'active' ? 'suspended' : 'activated'} successfully.`);
      fetchStudents();
    } else {
      setError(response.message || `Failed to change student status.`);
    }
    setLoading(false);
  };


  if (loading && !students.length) {
    return <LoadingSpinner />;
  }

  return (
    <div className="container mx-auto p-6 min-h-screen-minus-nav-footer">
      <h1 className="text-4xl font-bold text-gray-900 mb-8">Student Management</h1>

      {message && <Alert type="success" message={message} onClose={() => setMessage(null)} className="mb-4" />}
      {error && <Alert type="error" message={error} onClose={() => setError(null)} className="mb-4" />}

      <div className="flex justify-end mb-6">
        <Button onClick={openAddModal}>
          <i className="fas fa-plus mr-2"></i>Add New Student
        </Button>
      </div>

      <Card>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Name
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Email
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Phone
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {students.length > 0 ? (
                students.map(student => (
                  <tr key={student.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{student.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{student.email}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{student.phone || 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        student.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {student.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex space-x-2">
                        <Button onClick={() => openEditModal(student)} variant="secondary" size="sm">
                          Edit
                        </Button>
                        <Button onClick={() => handleToggleStatus(student)} variant={student.status === 'active' ? 'destructive' : 'primary'} size="sm">
                          {student.status === 'active' ? 'Suspend' : 'Activate'}
                        </Button>
                        <Button onClick={() => handleDelete(student.id)} variant="ghost" size="sm" className="text-red-600">
                          Delete
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-6 py-4 text-center text-gray-500">
                    No students found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={currentStudent ? 'Edit Student' : 'Add New Student'}>
        <form onSubmit={handleModalSubmit} className="space-y-4">
          <Input
            id="name"
            label="Full Name"
            type="text"
            value={formData.name}
            onChange={handleInputChange}
            required
            disabled={loading}
          />
          <Input
            id="email"
            label="Email Address"
            type="email"
            value={formData.email}
            onChange={handleInputChange}
            required
            disabled={loading}
          />
          <Input
            id="phone"
            label="Phone Number"
            type="tel"
            value={formData.phone}
            onChange={handleInputChange}
            disabled={loading}
          />
          {!currentStudent && ( // Only show password for new student
            <Input
              id="password"
              label="Password"
              type="password"
              value={formData.password}
              onChange={handleInputChange}
              required
              disabled={loading}
              placeholder="Set initial password"
            />
          )}
          {currentStudent && ( // Optional password change for existing student
            <Input
              id="password"
              label="New Password (optional)"
              type="password"
              value={formData.password}
              onChange={handleInputChange}
              disabled={loading}
              placeholder="Leave blank to keep current password"
            />
          )}
          <Button type="submit" className="w-full" loading={loading} disabled={loading}>
            {currentStudent ? 'Update Student' : 'Add Student'}
          </Button>
        </form>
      </Modal>
    </div>
  );
};

export default AdminStudentsPage;
