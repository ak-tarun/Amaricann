
import { apiRequest } from './api';
import { Course, Lecture, ApiResponse } from '../types';

export async function getAllCourses(): Promise<ApiResponse<Course[]>> {
  return apiRequest<Course[]>('/courses', 'GET');
}

export async function getCourseById(id: number): Promise<ApiResponse<Course>> {
  return apiRequest<Course>(`/courses/${id}`, 'GET');
}

export async function createCourse(data: FormData): Promise<ApiResponse<Course>> {
  return apiRequest<Course>('/admin/courses', 'POST', data);
}

export async function updateCourse(id: number, data: FormData): Promise<ApiResponse<Course>> {
  data.append('_method', 'PUT'); // Laravel typically expects _method for PUT/PATCH with FormData
  return apiRequest<Course>(`/admin/courses/${id}`, 'POST', data);
}

export async function deleteCourse(id: number): Promise<ApiResponse<any>> {
  return apiRequest<any>(`/admin/courses/${id}`, 'DELETE');
}

export async function getCourseLectures(courseId: number): Promise<ApiResponse<Lecture[]>> {
  return apiRequest<Lecture[]>(`/courses/${courseId}/lectures`, 'GET');
}

export async function createLecture(data: Lecture): Promise<ApiResponse<Lecture>> {
  return apiRequest<Lecture>('/admin/lectures', 'POST', data);
}

export async function updateLecture(id: number, data: Lecture): Promise<ApiResponse<Lecture>> {
  return apiRequest<Lecture>(`/admin/lectures/${id}`, 'PUT', data);
}

export async function deleteLecture(id: number): Promise<ApiResponse<any>> {
  return apiRequest<any>(`/admin/lectures/${id}`, 'DELETE');
}

export async function getStudentEnrollments(): Promise<ApiResponse<Course[]>> {
  return apiRequest<Course[]>('/student/enrollments', 'GET');
}

export async function enrollInCourse(courseId: number): Promise<ApiResponse<any>> {
  return apiRequest<any>('/student/enroll', 'POST', { course_id: courseId });
}
