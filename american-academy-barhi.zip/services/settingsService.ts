
import { apiRequest } from './api';
import { PrivacyPolicy, SocialLink, Setting, ApiResponse, SocialLinkStatus } from '../types';

// --- Privacy Policy ---
export async function getPrivacyPolicy(): Promise<ApiResponse<PrivacyPolicy>> {
  return apiRequest<PrivacyPolicy>('/settings/privacy-policy', 'GET');
}

export async function updatePrivacyPolicy(content: string): Promise<ApiResponse<PrivacyPolicy>> {
  return apiRequest<PrivacyPolicy>('/admin/privacy-policy', 'PUT', { content });
}

// --- Social Links ---
export async function getSocialLinks(): Promise<ApiResponse<SocialLink[]>> {
  return apiRequest<SocialLink[]>('/social-links', 'GET');
}

export async function createSocialLink(data: Omit<SocialLink, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<SocialLink>> {
  return apiRequest<SocialLink>('/admin/social-links', 'POST', data);
}

export async function updateSocialLink(id: number, data: Partial<Omit<SocialLink, 'id' | 'created_at' | 'updated_at'>>): Promise<ApiResponse<SocialLink>> {
  return apiRequest<SocialLink>(`/admin/social-links/${id}`, 'PUT', data);
}

export async function deleteSocialLink(id: number): Promise<ApiResponse<any>> {
  return apiRequest<any>(`/admin/social-links/${id}`, 'DELETE');
}

// --- General Settings (Logo, UPI, Gateway Keys etc.) ---
export async function getSettings(): Promise<ApiResponse<Setting[]>> {
  return apiRequest<Setting[]>('/admin/settings', 'GET');
}

export async function updateSetting(key: string, value: string): Promise<ApiResponse<Setting>> {
  return apiRequest<Setting>('/admin/settings', 'POST', { key, value }); // Assuming a generic update endpoint
}

export async function updateSettingsBatch(settings: { key: string; value: string }[]): Promise<ApiResponse<Setting[]>> {
  return apiRequest<Setting[]>('/admin/settings/batch', 'POST', { settings });
}

export async function uploadSettingImage(key: string, file: File): Promise<ApiResponse<Setting>> {
  const formData = new FormData();
  formData.append('key', key);
  formData.append('image', file);
  return apiRequest<Setting>('/admin/settings/image', 'POST', formData);
}
