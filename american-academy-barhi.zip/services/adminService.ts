
import { apiRequest } from './api';
import { Attendance, Payment, TimetableEntry, Certificate, ApiResponse, User } from '../types';
import { API_BASE_URL, JWT_TOKEN_KEY } from '../constants'; // Import API_BASE_URL and JWT_TOKEN_KEY

// --- Student Management ---
export async function getAllStudents(): Promise<ApiResponse<User[]>> {
  return apiRequest<User[]>('/admin/students', 'GET');
}

export async function createStudent(data: FormData): Promise<ApiResponse<User>> {
  return apiRequest<User>('/admin/students', 'POST', data);
}

export async function updateStudent(id: number, data: FormData): Promise<ApiResponse<User>> {
  data.append('_method', 'PUT');
  return apiRequest<User>(`/admin/students/${id}`, 'POST', data);
}

export async function deleteStudent(id: number): Promise<ApiResponse<any>> {
  return apiRequest<any>(`/admin/students/${id}`, 'DELETE');
}

export async function suspendStudent(id: number): Promise<ApiResponse<any>> {
  return apiRequest<any>(`/admin/students/${id}/suspend`, 'POST');
}

export async function activateStudent(id: number): Promise<ApiResponse<any>> {
  return apiRequest<any>(`/admin/students/${id}/activate`, 'POST');
}

// --- Attendance Management ---
export async function getAttendanceRecords(courseId?: number, date?: string): Promise<ApiResponse<Attendance[]>> {
  const params = new URLSearchParams();
  if (courseId) params.append('course_id', courseId.toString());
  if (date) params.append('date', date);
  return apiRequest<Attendance[]>(`/admin/attendance?${params.toString()}`, 'GET');
}

export async function markAttendance(data: { user_id: number; course_id: number; date: string; status: string }): Promise<ApiResponse<Attendance>> {
  return apiRequest<Attendance>('/admin/attendance', 'POST', data);
}

export async function updateAttendance(id: number, data: { status: string }): Promise<ApiResponse<Attendance>> {
  return apiRequest<Attendance>(`/admin/attendance/${id}`, 'PUT', data);
}

// --- Timetable Management ---
export async function getTimetable(): Promise<ApiResponse<TimetableEntry[]>> {
  return apiRequest<TimetableEntry[]>('/admin/timetable', 'GET');
}

export async function createTimetableEntry(data: Omit<TimetableEntry, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<TimetableEntry>> {
  return apiRequest<TimetableEntry>('/admin/timetable', 'POST', data);
}

export async function updateTimetableEntry(id: number, data: Omit<TimetableEntry, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<TimetableEntry>> {
  return apiRequest<TimetableEntry>(`/admin/timetable/${id}`, 'PUT', data);
}

export async function deleteTimetableEntry(id: number): Promise<ApiResponse<any>> {
  return apiRequest<any>(`/admin/timetable/${id}`, 'DELETE');
}

// --- Certificate Management ---
export async function generateCertificate(userId: number, courseId: number): Promise<ApiResponse<Certificate>> {
  return apiRequest<Certificate>('/api/certificates/generate', 'POST', { user_id: userId, course_id: courseId });
}

export async function getCertificates(): Promise<ApiResponse<Certificate[]>> {
  return apiRequest<Certificate[]>('/admin/certificates', 'GET');
}

// --- User Management (for Super Admin to manage other admins/staff) ---
export async function getAllUsers(role?: string): Promise<ApiResponse<User[]>> {
  const params = role ? `?role=${role}` : '';
  return apiRequest<User[]>(`/admin/users${params}`, 'GET');
}

export async function createUser(data: Omit<User, 'id' | 'created_at' | 'updated_at'> & {password: string}): Promise<ApiResponse<User>> {
  return apiRequest<User>('/admin/users', 'POST', data);
}

export async function updateUser(id: number, data: Partial<Omit<User, 'id' | 'created_at' | 'updated_at'>> & {password?: string}): Promise<ApiResponse<User>> {
  return apiRequest<User>(`/admin/users/${id}`, 'PUT', data);
}

export async function deleteUser(id: number): Promise<ApiResponse<any>> {
  return apiRequest<any>(`/admin/users/${id}`, 'DELETE');
}


// --- Reports Export ---
export async function exportStudentsReport(): Promise<ApiResponse<Blob>> {
  const token = localStorage.getItem(JWT_TOKEN_KEY); 
  const response = await fetch(`${API_BASE_URL}/admin/reports/students/export`, {
    headers: { 'Authorization': `Bearer ${token}` },
  });
  if (!response.ok) {
    return { success: false, message: 'Failed to export students report.' };
  }
  const blob = await response.blob();
  return { success: true, data: blob };
}

export async function exportAttendanceReport(courseId?: number, dateRange?: { start: string, end: string }): Promise<ApiResponse<Blob>> {
  const params = new URLSearchParams();
  if (courseId) params.append('course_id', courseId.toString());
  if (dateRange) {
    params.append('start_date', dateRange.start);
    params.append('end_date', dateRange.end);
  }
  const token = localStorage.getItem(JWT_TOKEN_KEY); 
  const response = await fetch(`${API_BASE_URL}/admin/reports/attendance/export?${params.toString()}`, {
    headers: { 'Authorization': `Bearer ${token}` },
  });
  if (!response.ok) {
    return { success: false, message: 'Failed to export attendance report.' };
  }
  const blob = await response.blob();
  return { success: true, data: blob };
}

export async function exportPaymentsReport(filters?: { status?: string, method?: string, userId?: number }): Promise<ApiResponse<Blob>> {
  const params = new URLSearchParams();
  if (filters?.status) params.append('status', filters.status);
  if (filters?.method) params.append('method', filters.method);
  if (filters?.userId) params.append('user_id', filters.userId.toString());
  const token = localStorage.getItem(JWT_TOKEN_KEY); 
  const response = await fetch(`${API_BASE_URL}/admin/reports/payments/export?${params.toString()}`, {
    headers: { 'Authorization': `Bearer ${token}` },
  });
  if (!response.ok) {
    return { success: false, message: 'Failed to export payments report.' };
  }
  const blob = await response.blob();
  return { success: true, data: blob };
}
