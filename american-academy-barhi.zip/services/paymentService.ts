
import { apiRequest } from './api';
import { Payment, ApiResponse, PaymentStatus } from '../types';

export async function submitManualUpiPayment(courseId: number, amount: number, txnId: string, screenshot: File): Promise<ApiResponse<Payment>> {
  const formData = new FormData();
  formData.append('course_id', courseId.toString());
  formData.append('amount', amount.toString());
  formData.append('txn_id', txnId);
  formData.append('screenshot', screenshot);

  return apiRequest<Payment>('/payments/manual', 'POST', formData);
}

export async function getStudentPaymentHistory(): Promise<ApiResponse<Payment[]>> {
  return apiRequest<Payment[]>('/student/payments', 'GET');
}

// Admin functions
export async function getAllPayments(): Promise<ApiResponse<Payment[]>> {
  return apiRequest<Payment[]>('/admin/payments', 'GET');
}

export async function verifyManualPayment(paymentId: number, status: PaymentStatus): Promise<ApiResponse<Payment>> {
  return apiRequest<Payment>(`/admin/payments/${paymentId}/verify`, 'POST', { status });
}
