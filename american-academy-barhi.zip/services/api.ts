
import { API_BASE_URL, JWT_TOKEN_KEY } from '../constants';
import { ApiResponse } from '../types';

interface RequestOptions extends RequestInit {
  token?: string;
}

export async function apiRequest<T>(
  endpoint: string,
  method: string = 'GET',
  data?: any,
  options?: RequestOptions
): Promise<ApiResponse<T>> {
  const token = localStorage.getItem(JWT_TOKEN_KEY) || options?.token;

  const headers: HeadersInit = {
    'Accept': 'application/json',
  };

  if (data instanceof FormData) {
    // If FormData, let browser set Content-Type header with boundary
  } else {
    headers['Content-Type'] = 'application/json';
  }


  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const config: RequestInit = {
    method,
    headers,
    ...options,
  };

  if (data && method !== 'GET' && method !== 'HEAD') {
    if (data instanceof FormData) {
      config.body = data;
    } else {
      config.body = JSON.stringify(data);
    }
  }

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, config);

    // If no content, just return success
    if (response.status === 204) {
      return { success: true, data: undefined as T };
    }

    const jsonResponse: ApiResponse<T> = await response.json();

    if (!response.ok) {
      return {
        success: false,
        message: jsonResponse.message || `API Error: ${response.status} ${response.statusText}`,
        errors: jsonResponse.errors,
      };
    }

    return { success: true, data: jsonResponse.data as T, message: jsonResponse.message };
  } catch (error) {
    console.error('API request failed:', error);
    return { success: false, message: 'Network error or server unreachable.' };
  }
}
