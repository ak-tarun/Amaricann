
import React, { useEffect, useState } from 'react';
import * as adminService from '../../services/adminService';
import * as paymentService from '../../services/paymentService';
import * as courseService from '../../services/courseService';
import { Payment, Course, User, PaymentStatus, PaymentMethod } from '../../types';
import LoadingSpinner from '../../components/LoadingSpinner';
import Card from '../../components/Card';
import Alert from '../../components/Alert';
import Button from '../../components/Button';
import Modal from '../../components/Modal';

const AdminPaymentsPage: React.FC = () => {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [students, setStudents] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState<Payment | null>(null);

  const [filterStatus, setFilterStatus] = useState<PaymentStatus | ''>('');
  // Fix: Correct type for filterMethod to be PaymentMethod | ''
  const [filterMethod, setFilterMethod] = useState<PaymentMethod | ''>('');

  useEffect(() => {
    fetchPaymentsAndData();
  }, []); // eslint-disable-next-line react-hooks/exhaustive-deps

  useEffect(() => {
    fetchPaymentsAndData(filterStatus, filterMethod);
  }, [filterStatus, filterMethod]); // eslint-disable-next-line react-hooks/exhaustive-deps


  const fetchPaymentsAndData = async (status?: PaymentStatus | '', method?: string) => {
    setLoading(true);
    setError(null);

    const [paymentsRes, coursesRes, studentsRes] = await Promise.all([
      paymentService.getAllPayments(),
      courseService.getAllCourses(),
      adminService.getAllStudents(),
    ]);

    if (paymentsRes.success && paymentsRes.data) {
        let filteredPayments = paymentsRes.data;
        if (status) {
            filteredPayments = filteredPayments.filter(p => p.status === status);
        }
        if (method) {
            // Fix: Cast method to PaymentMethod enum for comparison
            filteredPayments = filteredPayments.filter(p => p.method === method as PaymentMethod);
        }
        setPayments(filteredPayments);
    } else {
      setError(paymentsRes.message || 'Failed to fetch payments.');
    }

    if (coursesRes.success && coursesRes.data) {
      setCourses(coursesRes.data);
    } else {
      setError(coursesRes.message || 'Failed to fetch courses.');
    }

    if (studentsRes.success && studentsRes.data) {
        setStudents(studentsRes.data);
    } else {
        setError(studentsRes.message || 'Failed to fetch students.');
    }

    setLoading(false);
  };

  const getCourseTitle = (courseId: number | undefined) => {
    if (!courseId) return 'N/A';
    const course = courses.find(c => c.id === courseId);
    return course ? course.title : 'N/A';
  };

  const getStudentName = (userId: number) => {
    const student = students.find(s => s.id === userId);
    return student ? student.name : 'N/A';
  };

  const getStatusColor = (status: PaymentStatus) => {
    switch (status) {
      case PaymentStatus.COMPLETED:
      case PaymentStatus.VERIFIED:
        return 'bg-green-100 text-green-800';
      case PaymentStatus.PENDING:
        return 'bg-yellow-100 text-yellow-800';
      case PaymentStatus.FAILED:
      case PaymentStatus.REJECTED:
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const openVerificationModal = (payment: Payment) => {
    setSelectedPayment(payment);
    setIsModalOpen(true);
  };

  const handleVerifyPayment = async (status: PaymentStatus) => {
    if (!selectedPayment) return;

    setLoading(true);
    setMessage(null);
    setError(null);

    const response = await paymentService.verifyManualPayment(selectedPayment.id, status);

    if (response.success) {
      setMessage(response.message || `Payment marked as ${status} successfully.`);
      setIsModalOpen(false);
      fetchPaymentsAndData(filterStatus, filterMethod);
    } else {
      setError(response.message || 'Failed to update payment status.');
    }
    setLoading(false);
  };

  const handleExport = async () => {
    setLoading(true);
    setError(null);
    const response = await adminService.exportPaymentsReport({ status: filterStatus || undefined, method: filterMethod || undefined });
    if (response.success && response.data) {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `payments_report_${new Date().toISOString()}.xlsx`);
        document.body.appendChild(link);
        link.click();
        link.remove();
        setMessage('Payment report downloaded successfully.');
    } else {
        setError(response.message || 'Failed to export payments report.');
    }
    setLoading(false);
  };


  if (loading && (!payments.length || !courses.length || !students.length)) {
    return <LoadingSpinner />;
  }

  return (
    <div className="container mx-auto p-6 min-h-screen-minus-nav-footer">
      <h1 className="text-4xl font-bold text-gray-900 mb-8">Payment Management</h1>

      {message && <Alert type="success" message={message} onClose={() => setMessage(null)} className="mb-4" />}
      {error && <Alert type="error" message={error} onClose={() => setError(null)} className="mb-4" />}

      <Card className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Payment Filters & Export</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 items-end">
          <div>
            <label htmlFor="filterStatus" className="block text-sm font-medium text-gray-700 mb-1">
              Filter by Status
            </label>
            <select
              id="filterStatus"
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as PaymentStatus | '')}
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            >
              <option value="">All Statuses</option>
              {Object.values(PaymentStatus).map(status => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="filterMethod" className="block text-sm font-medium text-gray-700 mb-1">
              Filter by Method
            </label>
            <select
              id="filterMethod"
              value={filterMethod}
              // Fix: Cast e.target.value to PaymentMethod | ''
              onChange={(e) => setFilterMethod(e.target.value as PaymentMethod | '')}
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            >
              <option value="">All Methods</option>
              {Object.values(PaymentMethod).map(method => (
                // Fix: Ensure method is treated as a string value for display
                <option key={method} value={method}>
                  {method.toUpperCase()}
                </option>
              ))}
            </select>
          </div>
          <Button onClick={handleExport} variant="outline" className="w-full">
            <i className="fas fa-file-excel mr-2"></i> Export Payment History
          </Button>
        </div>
      </Card>

      <Card>
        <h2 className="text-2xl font-bold text-gray-900 mb-4">All Payments</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Student
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Course
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Method
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Transaction ID
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {payments.length > 0 ? (
                payments.map(payment => (
                  <tr key={payment.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{getStudentName(payment.user_id)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{getCourseTitle(payment.course_id)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">₹{payment.amount}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{payment.method.toUpperCase()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{payment.txn_id || 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(payment.status)}`}>
                        {payment.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(payment.created_at).toLocaleDateString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      {payment.method === PaymentMethod.UPI && payment.status === PaymentStatus.PENDING && (
                        <Button onClick={() => openVerificationModal(payment)} variant="primary" size="sm">
                          Verify
                        </Button>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="px-6 py-4 text-center text-gray-500">
                    No payments found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Verify UPI Payment">
        {selectedPayment && (
          <div>
            <p className="mb-2 text-gray-700"><strong>Student:</strong> {getStudentName(selectedPayment.user_id)}</p>
            <p className="mb-2 text-gray-700"><strong>Course:</strong> {getCourseTitle(selectedPayment.course_id)}</p>
            <p className="mb-2 text-gray-700"><strong>Amount:</strong> ₹{selectedPayment.amount}</p>
            <p className="mb-4 text-gray-700"><strong>Transaction ID:</strong> {selectedPayment.txn_id}</p>
            {selectedPayment.screenshot_url && (
              <div className="mb-6">
                <p className="font-medium text-gray-800 mb-2">Payment Screenshot:</p>
                <a href={selectedPayment.screenshot_url} target="_blank" rel="noopener noreferrer">
                  <img src={selectedPayment.screenshot_url} alt="Payment Screenshot" className="max-w-xs max-h-48 rounded-md border shadow-sm" />
                </a>
              </div>
            )}
            <div className="flex justify-end space-x-3 mt-6">
              <Button onClick={() => handleVerifyPayment(PaymentStatus.REJECTED)} variant="destructive" disabled={loading}>
                Reject
              </Button>
              <Button onClick={() => handleVerifyPayment(PaymentStatus.VERIFIED)} variant="primary" disabled={loading}>
                Verify
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default AdminPaymentsPage;
