
import { apiRequest } from './api';
import { Attendance, TimetableEntry, Certificate, ApiResponse } from '../types';

export async function getStudentAttendance(): Promise<ApiResponse<Attendance[]>> {
  return apiRequest<Attendance[]>('/student/attendance', 'GET');
}

export async function getStudentTimetable(): Promise<ApiResponse<TimetableEntry[]>> {
  return apiRequest<TimetableEntry[]>('/student/timetable', 'GET');
}

export async function getStudentCertificates(): Promise<ApiResponse<Certificate[]>> {
  return apiRequest<Certificate[]>('/student/certificates', 'GET');
}
